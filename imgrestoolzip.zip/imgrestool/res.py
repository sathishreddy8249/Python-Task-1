import os
from PIL import Image

def resize_images(input_folder, output_folder, width, height, output_format="JPEG"):
    # Create output folder if not exists
    os.makedirs(output_folder, exist_ok=True)

    # Loop through all files in input folder
    for filename in os.listdir(input_folder):
        file_path = os.path.join(input_folder, filename)

        # Skip if it's not a file
        if not os.path.isfile(file_path):
            continue

        try:
            # Open image
            with Image.open(file_path) as img:
                # Resize while ignoring aspect ratio (fixed size)
                resized_img = img.resize((width, height))

                # Convert to RGB if needed (for JPEG/PNG)
                if resized_img.mode in ("RGBA", "P"):
                    resized_img = resized_img.convert("RGB")

                # Create output file path
                base_name, _ = os.path.splitext(filename)
                new_filename = f"{base_name}.{output_format.lower()}"
                output_path = os.path.join(output_folder, new_filename)

                # Save resized image
                resized_img.save(output_path, output_format)
                print(f"✔ Saved: {output_path}")

        except Exception as e:
            print(f"❌ Error processing {filename}: {e}")

# Example usage
if __name__ == "__main__":
    input_folder = "input_images"     # Folder with original images
    output_folder = "resized_images"  # Folder to save resized images
    resize_images(input_folder, output_folder, width=300, height=300, output_format="JPEG")
